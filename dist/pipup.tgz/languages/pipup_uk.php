<?php
/**
 * PiPup: український словник рядків (код uk).
 */

$PIPUP_STRINGS = array(

    // Заголовки вікон PiPup.
    'PIPUP_TITLE_NOTIFICATION' => 'Повідомлення',
    'PIPUP_TITLE_QUESTION'     => 'Запитання',
    'PIPUP_TITLE_CAMERA'       => 'Камера',
    'PIPUP_TITLE_SOUND'        => "\xF0\x9F\x94\x8A Повідомлення", // 🔊
    'PIPUP_TITLE_IMAGE'        => "\xF0\x9F\x96\xBC",             // 🖼
    'PIPUP_TITLE_VIDEO'        => "\xE2\x96\xB6",                 // ▶

    // Опис плеєра pipup_play.
    'PIPUP_PLAYER_TITLE'        => 'PiPup (спливаюче вікно)',
    'PIPUP_PLAYER_DESC_SHORT'   => 'Показує звук, зображення, відео, WebRTC та вебсторінки у спливаючому вікні PiPup на Android-пристрої (ТВ, приставка, планшет, панель, телефон); текст і голос повідомлень — через тип TTS <b>pipup</b>.',
    'PIPUP_PLAYER_DETAILS'      => 'Детальніше',
    'PIPUP_PLAYER_DESC_TYPES'   => 'Тип вікна обирається за посиланням або розширенням: <b>звук</b> (mp3, wav, ogg, m4a…), <b>зображення</b> (jpg, png, gif, webp; локальний файл надсилається файлом), <b>SVG</b>, <b>відео</b> (mp4, webm, m3u8, rtsp://…), <b>WebRTC</b> go2rtc (…/api/webrtc?src=…), <b>вебсторінка / MJPEG</b> (інші http-посилання).',
    'PIPUP_PLAYER_DESC_FILES'   => 'Файли — з вебкореня MajorDoMo або за посиланням. Звук і відео показуються протягом файлу, потоки — 60 с, зображення — 30 с.',
    'PIPUP_PLAYER_DESC_STOP'    => '«Стоп» закриває всі вікна PiPup (звук за посиланням дограє); пауза, гучність і статус недоступні.',
    'PIPUP_PLAYER_DESC_REQ'     => '<b>Вимоги:</b> Android 6.0.1+ з форком PiPup (mhoogenbosch) 0.27+ — <a href="https://github.com/mhoogenbosch/PiPup/releases/latest/download/PiPup.apk" target="_blank">завантажити APK</a>; PHP з curl, BASE_URL у config.php з портом вебсервера. У полі «Адреса» — лише IP або ім’я пристрою, порт PiPup — у полі «Порт PiPup» (порожньо — 7979).',
    'PIPUP_PLAYER_DESC_VOICE'   => '<b>Текст і голос повідомлень</b> (say, sayTo, ask) виводить тип TTS <b>pipup</b>: увімкніть «Може говорити» та оберіть pipup. Його налаштування задається тут, у полі <b>«Голос повідомлень»</b> (в інших плеєрів це поле «Ім’я користувача»):',
    'PIPUP_PLAYER_VOICE_EMPTY'  => 'порожньо — голос будь-якого генератора мовлення;',
    'PIPUP_PLAYER_VOICE_TAGS'   => 'мітка генератора — лише його голос: <code>sanotts</code>, <code>piper_tts</code>, <code>rh</code>, <code>sapi</code>, <code>yandex</code>, <code>google</code>, <code>ivona</code>, <code>tilde</code>; кілька через кому;',
    'PIPUP_PLAYER_VOICE_DEVICE' => '<code>device</code> — говорити синтезатором самого пристрою, файли генераторів не використовувати.',
    'PIPUP_PLAYER_DESC_TIME'    => 'Тривалість вікна повідомлення обчислюється за довжиною тексту (10–60 с).',
    'PIPUP_PLAYER_DESC_HINT'    => 'Якщо текстові вікна не з’являються, перевірте поріг рівня повідомлень термінала та пріоритет модуля terminals (модулі з BREAK, наприклад yandex_tts, зупиняють подію).',

    // Підписи полів картки термінала.
    'PIPUP_FIELD_VOICE'  => 'Голос повідомлень:',
    'PIPUP_FIELD_PORT'   => 'Порт PiPup:',
    'PIPUP_HINT_VOICE'   => 'порожньо — будь-який голос; sanotts, yandex… — лише ці; device — голос пристрою',
    'PIPUP_HINT_PORT'    => 'порожньо — 7979',
    'PIPUP_VOICE_ANY'    => 'Будь-який голос — перший готовий файл генератора',
    'PIPUP_VOICE_DEVICE' => 'Голос пристрою (device)',
    'PIPUP_VOICE_CACHE'  => '%s — %d у кеші',
    'PIPUP_VOICE_PICK'   => 'Обрати зі списку',

    // Генератори мовлення.
    'PIPUP_ENGINE_SANOTTS'   => 'sanoTTS',
    'PIPUP_ENGINE_PIPER_TTS' => 'Piper',
    'PIPUP_ENGINE_SAPI'      => 'Windows SAPI',
    'PIPUP_ENGINE_RH'        => 'RHVoice',
    'PIPUP_ENGINE_YANDEX'    => 'Яндекс',
    'PIPUP_ENGINE_GOOGLE'    => 'Google',
    'PIPUP_ENGINE_IVONA'     => 'Ivona',
    'PIPUP_ENGINE_TILDE'     => 'Tilde',

    // Відповіді розборщика голосових команд.
    'PIPUP_INTENT_UNKNOWN'        => 'Команду не розпізнано',
    'PIPUP_INTENT_SAY_DONE'       => 'Повідомлення показано',
    'PIPUP_INTENT_CAMERA_DONE'    => 'Камеру показано',
    'PIPUP_INTENT_IMAGE_DONE'     => 'Зображення показано',
    'PIPUP_INTENT_CLOSE_DONE'     => 'Вікна закрито',
    'PIPUP_INTENT_CAMERA_UNKNOWN' => 'Невідома камера',
    'PIPUP_INTENT_ERROR'          => 'Помилка PiPup',

    // Простий пристрій.
    'PIPUP_DEVICE_TITLE'      => 'Екран PiPup',
    'PIPUP_DEVICE_ALT_TITLES' => 'піпап, екран повідомлень, спливаюче вікно, поп-ап вікно',

    // Страница настроек модуля pipup_admin.
    'PIPUP_ADMIN_TITLE' => 'PiPup — налаштування',
    'PIPUP_ADMIN_SUBTITLE' => 'Повідомлення, голос і наміри для Android-пристроїв',
    'PIPUP_ADMIN_SAVED' => 'Налаштування збережено.',
    'PIPUP_ADMIN_RESET_DONE' => 'Відновлено налаштування за замовчуванням.',
    'PIPUP_ADMIN_ERROR' => 'Помилка',
    'PIPUP_ADMIN_SAVE' => 'Зберегти налаштування',
    'PIPUP_ADMIN_RESET' => 'Відновити за замовчуванням',
    'PIPUP_ADMIN_PROVISION' => 'Створити/оновити «Простий пристрій»',
    'PIPUP_ADMIN_TEST' => 'Надіслати тестове повідомлення',
    'PIPUP_ADMIN_GROUP_LANG' => 'Мова і голос',
    'PIPUP_ADMIN_LANGUAGE' => 'Мова тексту вікон',
    'PIPUP_ADMIN_LANGUAGE_HINT' => 'auto — мова сайту MajorDoMo (ua вважається uk)',
    'PIPUP_ADMIN_TTS_LANGUAGE' => 'Мова синтезатора пристрою',
    'PIPUP_ADMIN_TTS_HINT' => 'auto — en-US / ru-RU / uk-UA; довільний код BCP-47',
    'PIPUP_ADMIN_VOICE_FILTER' => 'Генератор мовлення за замовчуванням',
    'PIPUP_ADMIN_VOICE_HINT' => 'Порожньо — будь-який генератор; мітки через кому; device — синтезатор пристрою',
    'PIPUP_ADMIN_GROUP_DURATION' => 'Тривалість вікон',
    'PIPUP_ADMIN_TEXT_BASE' => 'Текст: база, с',
    'PIPUP_ADMIN_TEXT_CHARS' => 'Текст: секунд на N символів',
    'PIPUP_ADMIN_TEXT_MAX' => 'Текст: максимум, с',
    'PIPUP_ADMIN_SOUND_DURATION' => 'Звук, с',
    'PIPUP_ADMIN_IMAGE_DURATION' => 'Зображення, с',
    'PIPUP_ADMIN_VIDEO_DURATION' => 'Відео/потік, с',
    'PIPUP_ADMIN_GROUP_WINDOW' => 'Вікна',
    'PIPUP_ADMIN_STACK' => 'Розкладка',
    'PIPUP_ADMIN_POSITION' => 'Позиція',
    'PIPUP_ADMIN_FALLBACK' => 'Повторювати без полів форка при HTTP 400',
    'PIPUP_ADMIN_DEBUG' => 'Детальний лог (канал terminals)',
    'PIPUP_ADMIN_GROUP_COLORS' => 'Кольори',
    'PIPUP_ADMIN_COLOR_TITLE' => 'Заголовок (текстові вікна)',
    'PIPUP_ADMIN_COLOR_MESSAGE' => 'Текст (текстові вікна)',
    'PIPUP_ADMIN_COLOR_BG' => 'Фон (текстові вікна)',
    'PIPUP_ADMIN_MEDIA_COLOR_TITLE' => 'Заголовок (медіа-вікна)',
    'PIPUP_ADMIN_MEDIA_COLOR_MESSAGE' => 'Текст (медіа-вікна)',
    'PIPUP_ADMIN_MEDIA_COLOR_BG' => 'Фон (медіа-вікна)',
    'PIPUP_ADMIN_GROUP_DEVICE' => 'Простий пристрій і наміри',
    'PIPUP_ADMIN_TERMINAL' => 'Термінал за замовчуванням',
    'PIPUP_ADMIN_TERMINAL_HINT' => 'Ім’я з картки «Термінали», використовують сценарії та голосові команди',
    'PIPUP_ADMIN_CAMERAS' => 'Карта камер (JSON)',
    'PIPUP_ADMIN_CAMERAS_HINT' => '{"default": "http://.../api/webrtc?src=door", "door": "..."}',
    'PIPUP_ADMIN_CAMERA_TYPE' => 'Тип вікна камери',
    'PIPUP_ADMIN_ON_ACTION' => 'Дія «увімкнути» простого пристрою',
    'PIPUP_ADMIN_DEVICE_OBJECT' => 'Ім’я об’єкта простого пристрою',
    'PIPUP_ADMIN_PROVISION_HINT' => 'Створює об’єкт SPipupNotifier, його методи та рядок у таблиці devices. Повтор безпечний.',
    'PIPUP_ADMIN_DEVICE_OK' => 'Простий пристрій створено/оновлено: %s',
    'PIPUP_ADMIN_DEVICE_FAIL' => 'Не вдалося створити простий пристрій: %s',
    'PIPUP_ADMIN_GROUP_HELP' => 'Як користуватися',
    'PIPUP_ADMIN_HELP' => 'У картці термінала оберіть pipup як тип TTS та pipup_play як тип плеєра. Голосові команди обробляє метод SPipupNotifier.intent і подія COMMAND модуля devices.',
    'PIPUP_ADMIN_VERSION' => 'Версія',
    'PIPUP_ADMIN_AUTO' => 'auto (мова сайту)',
    'PIPUP_ADMIN_YES' => 'так',
    'PIPUP_ADMIN_NO' => 'ні',
    'PIPUP_ADMIN_TEST_OK' => 'Тестове повідомлення надіслано',
    'PIPUP_ADMIN_TEST_FAIL' => 'Не вдалося надіслати тестове повідомлення',
);
